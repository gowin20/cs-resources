#include <stdio.h>

void hello(void) {
  printf("Hello world from libhello\n");
}
