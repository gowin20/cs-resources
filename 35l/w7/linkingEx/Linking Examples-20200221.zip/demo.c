#include "libhello.h"

int main(void) {
 hello();
 return 0;
}
