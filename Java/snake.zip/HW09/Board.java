/*
 * 
 * 
 * 
 * 
 * 
 */

public class Board {
    private final int ROW_COUNT;
    private final int COL_COUNT;
    
    private Cell[][] cells;
    
    public Board(int rowCount, int colCount) {
        this.ROW_COUNT = rowCount;
        this.COL_COUNT = colCount;
        
        cells = new Cell[rowCount][colCount];
        for (int row = 0; row < rowCount; row++) {
            for (int col = 0; col < colCount; col++) {
                cells[row][col] = new Cell(row, col, -1);
            }
        }
    }
    
    public int getRowCount() {
        return this.ROW_COUNT;
    }
    
    public int getColCount() {
        return this.COL_COUNT;
    }
    
    public Cell[][] getCells() {
        return this.cells;
    }
    
    public void setCells(Cell[][] cells) {
        boolean isNull = false;
        for (int i = 0; i < this.ROW_COUNT; i++) {
            for (int j = 0; j < this.COL_COUNT; j++) {
                if (cells[i][j] != null) {
                    isNull = true;
                }
            }
        }
        
        if (!isNull) {
            this.cells = cells;
        }
    }
    
    public void draw() {
        for (int i = 0; i < cells.length; i++) {
            for (int j = 0; j < cells[0].length; j++) {
                cells[i][j].draw(this.ROW_COUNT, this.COL_COUNT);
            }
        }
    }
    
    public void makeApple() {
        int row = (int) (Math.random() * this.ROW_COUNT);
        int col = (int) (Math.random() * this.COL_COUNT);
        cells[row][col].setType(0);
    }  
}