/*
 * 
 * 
 * 
 * 
 * 
 * 
 */

public class snakeGame {
    private static final int NO_DIRECTION = 0;
    private static final int UP_DIRECTION = 2;
    private static final int DOWN_DIRECTION = -2;
    private static final int LEFT_DIRECTION = -1;
    private static final int RIGHT_DIRECTION = 1;
    
    private Snake snake;
    private Board board;
    private int snakeDirection;
    private boolean isGameOver;
    
    public snakeGame(Snake snake, Board board) {
        this.snake = snake;
        this.board = board;
    }
    
    public Snake getSnake() {
        return this.snake;
    }
    
    public Board getBoard() {
        return this.board;
    }
    
    public void setBoard(Board board) {
        if (board != null) {
            this.board = board;
        }
    }
    
    public void setSnake(Snake snake) {
        if (snake != null) {
            this.snake = snake;
        }
    }
    
    public boolean getGameOver() {
        return this.isGameOver;
    }
    
    public int getDirection() {
        return this.snakeDirection;
    }
    
    public void setDirection(int direction) {
        if (direction < 3 && direction > -3) {
            this.snakeDirection = snakeDirection;
        }
    }
    
    // Need to update the game at regular intervals, 
    // and accept user input from the Keyboard. 
    public void update(char ch) {
        if (!isGameOver) {
            if (snakeDirection != NO_DIRECTION) {
                Cell nextCell = getNextCell(snake.getHead());
                
                if (snake.checkIfCrashed(nextCell)) {
                    setDirection(NO_DIRECTION);
                    isGameOver = true;
                }
                
                if (nextCell.getRow() > board.getRowCount() || nextCell.getRow() <= 0 || 
                    nextCell.getCol() > board.getColCount() || nextCell.getCol() <= 0) {
                    isGameOver = true;
                }
                
                else {
                    snake.moveCell(nextCell);
                    if (nextCell.getType() == 0) {
                        snake.elongate();
                        board.makeApple();
                    }
                }
                
                if (ch == 'a') {
                    snakeDirection = LEFT_DIRECTION;
                }
                else if (ch == 'w') {
                    snakeDirection = UP_DIRECTION;
                }
                else if (ch == 'd') {
                    snakeDirection = RIGHT_DIRECTION;
                }
                else if (ch == 's') {
                    snakeDirection = DOWN_DIRECTION;
                }
            }
        }
    }
    
    private Cell getNextCell(Cell currentPosition) {
        int row = currentPosition.getRow();
        int col = currentPosition.getCol();
        
        if (snakeDirection == UP_DIRECTION) {
            row++;
        }
        else if (snakeDirection == DOWN_DIRECTION) {
            row--;
        }
        else if (snakeDirection == RIGHT_DIRECTION) {
            col++;
        }
        else if (snakeDirection == LEFT_DIRECTION) {
            col--;
        }
        
        Cell nextCell = board.getCells()[row][col];
        
        return nextCell;
    }
    
    public static void main(String[] args) {
        Cell firstCell = new Cell(0, 0, 1);
        Snake snake = new Snake(firstCell);
        Board board = new Board(10, 10);
        snakeGame newGame = new snakeGame(snake, board);
        newGame.isGameOver = false;
        newGame.snakeDirection = RIGHT_DIRECTION;
        
        // Need to update the game at regular intervals, 
        // and accept user input from the Keyboard. 
        
        PennDraw.enableAnimation(250);
        while (!newGame.isGameOver) {
            newGame.update(PennDraw.nextKeyTyped());
            board.draw();
            
            PennDraw.advance();
        }
        PennDraw.disableAnimation();
    } 
}