/*
 * 
 * 
 * 
 * 
 * 
 * 
 */

import java.util.LinkedList;

public class Snake {
    private LinkedList<Cell> snakeList = new LinkedList<Cell>();
    private Cell head;
    
    public Snake(Cell initialPosition) {
        this.head = initialPosition;
        snakeList.add(this.head);
    }
    
    public void elongate() {
        snakeList.add(this.head);
    }

    public Cell getHead() {
        return this.head;
    }
    
    public void setHead(Cell head) {
        if (head != null) {
            this.head = head;
        }
    }
    
    public void moveCell(Cell nextCell) {
        Cell tail = snakeList.removeLast();
        tail.setType(-1);
        
        head = nextCell;
        snakeList.addFirst(this.head);
    }
    
    public boolean checkIfCrashed(Cell nextCell) {
        for (Cell cell : snakeList) {
            if (cell == nextCell) {
                return true;
            }
        }
        return false;
    }
    
    public void draw(int rowCount, int colCount) {
        for (Cell cell: snakeList) {
            cell.draw(rowCount, colCount);
        }
    }
    
    public LinkedList<Cell> getSnakePartList() {
        return snakeList;
    } 
}