/*
 * 
 * 
 * 
 * 
 * 
 * 
 */


public class Cell {
    private final int row;
    private final int col;
    private int type;
    private final int EMPTY_TYPE = -1;
    private final int APPLE_TYPE = 0;
    private final int SNAKE_TYPE = 1;
    
    public Cell(int row, int col, int type) {
        this.row = row;
        this.col = col;
        this.type = type;
    }
    
    public int getCol() {
        return this.col;
    }
    
    public int getRow() {
        return this.row;
    }
    
    
    public void draw(int rowCount, int colCount) {
        if (this.type == EMPTY_TYPE){
            PennDraw.setPenColor(0, 0, 0);
        }
        else if (this.type == APPLE_TYPE) {
            PennDraw.setPenColor(255, 0, 0);
        }
        else if (this.type == SNAKE_TYPE) {
            PennDraw.setPenColor(0, 255, 0);
        }
        PennDraw.filledRectangle(this.row, this.col, 1 / rowCount, 1 / colCount); 
    }
    
    public int getType() {
        return this.type;
    }
    
    public void setType(int type) {
        this.type = type;
    }
}